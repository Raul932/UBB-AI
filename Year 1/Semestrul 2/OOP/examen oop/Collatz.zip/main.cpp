#include "Collatz.h"


int main(){
    Collatz collatz;
    collatz.add(160);
    collatz.add(17);
    collatz.add(12);
    collatz.printSequence();
    return 0;

}