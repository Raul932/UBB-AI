#ifndef COLLATZ_H
#define COLLATZ_H
#include <unordered_map>
struct Nod{
    Nod* previous;
    Nod* next;
    int info;

    ~Nod();
};

class Collatz{
    private:
    Nod* head;
    std::unordered_map<int, int> visited;

    void CollatzMate(Nod* node);
    
    
    public:
    Collatz();
    ~Collatz();

    void add(int x);
    void printSequence();
};


#endif